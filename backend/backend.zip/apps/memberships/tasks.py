from celery import shared_task

from .services import expire_cash_requests, expire_overdue_memberships, run_reminder_cycle


@shared_task
def expire_memberships_task():
    """Periodic: release expired memberships so their seats free up."""
    return expire_overdue_memberships()


@shared_task
def run_membership_reminders():
    """Daily: expire overdue memberships and send renewal reminders."""
    return run_reminder_cycle()


@shared_task
def expire_cash_payment_requests():
    """Periodic: cancel cash requests that were not approved within 3 days."""
    return expire_cash_requests()
