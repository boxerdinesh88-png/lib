"""Membership business logic: pricing, seat assignment, activation, payments.

Seat availability rule (§6 of the spec): a seat is available for a given
shift + date range when no other *active* membership occupies that seat with
an overlapping shift AND an overlapping date range. The same physical seat
may therefore be sold to different members for non-overlapping shifts.
"""
import hashlib
import hmac
import logging
from datetime import date, timedelta
from decimal import Decimal

from django.conf import settings
from django.utils import timezone

logger = logging.getLogger("libseat.memberships")

CASH_REQUEST_TTL = timedelta(days=3)


def amount_paise(amount) -> int:
    return int(round(float(amount) * 100))


def membership_amount(shift, months: int):
    """Block's monthly price × duration months."""
    return shift.price * Decimal(int(months))


def seat_is_available(seat, shift, start_date, end_date, exclude_membership=None, user=None):
    """True when no active membership *or* active seat booking blocks `seat`.

    Bookings (held/confirmed by someone else) lock the seat for the requested
    shift + date range, mirroring what the 3D map shows in real time.
    """
    from .models import Membership

    overlapping = Membership.objects.filter(
        seat=seat,
        status="active",
        start_date__lte=end_date,
        end_date__gte=start_date,
    ).select_related("shift")
    if exclude_membership:
        overlapping = overlapping.exclude(pk=exclude_membership.pk)
    for membership in overlapping:
        if membership.shift.overlaps(shift):
            return False

    from apps.seats.services import booking_blocks_seat

    if booking_blocks_seat(seat, shift, start_date, end_date, user=user):
        return False
    return True


def seats_availability(seats, shift, start_date, end_date, user=None):
    """Set-based ``available`` + ``held`` flags for a whole seat queryset.

    Replaces the per-seat ``seat_is_available``/``held_by_other`` loops (2-3
    queries per seat, each with a row lock on a read path) with two
    set-based queries, so the seat-map endpoint drops from ~111 queries to ~5.
    Semantics are identical to the per-seat helpers:

    - a seat is unavailable when an overlapping *active* membership on the
      same seat has an overlapping shift and date range (own memberships count
      too, matching the existing behaviour);
    - a seat is unavailable when someone else holds a live booking (held with
      ``held_until`` in the future) or has a confirmed booking for the slot.

    ``held`` is True only when another user is *currently holding* the seat.
    """
    from apps.seats.models import Booking
    from django.utils import timezone

    from .models import Membership

    now = timezone.now()
    seat_ids = [seat.id for seat in seats]
    available = {str(seat.id): True for seat in seats}
    held = {str(seat.id): False for seat in seats}

    overlapping = Membership.objects.filter(
        seat_id__in=seat_ids,
        status="active",
        start_date__lte=end_date,
        end_date__gte=start_date,
    ).values_list("seat_id", "shift__start_time", "shift__end_time")
    for seat_id, shift_start, shift_end in overlapping:
        if shift_start < shift.end_time and shift_end > shift.start_time:
            available[str(seat_id)] = False

    bookings = Booking.objects.filter(
        seat_id__in=seat_ids,
        shift=shift,
        start_date__lte=end_date,
        end_date__gte=start_date,
        status__in=("held", "confirmed"),
    ).values_list("seat_id", "status", "held_until")
    if user is not None and user.is_authenticated:
        bookings = bookings.exclude(user=user)
    for seat_id, booking_status, held_until in bookings:
        key = str(seat_id)
        if booking_status == "confirmed" or (
            booking_status == "held" and held_until and held_until > now
        ):
            available[key] = False
            if booking_status == "held":
                held[key] = True

    return available, held


def auto_assign_seat(membership):
    """Assign the first available seat matching the member's gender section."""
    from apps.library.models import Seat

    candidates = Seat.objects.filter(
        is_active=True, section__in=membership.member.allowed_sections
    ).order_by("seat_number")
    for seat in candidates:
        if seat_is_available(
            seat,
            membership.shift,
            membership.start_date,
            membership.end_date,
            exclude_membership=membership,
            user=membership.member,
        ):
            membership.seat = seat
            membership.save(update_fields=["seat"])
            return seat
    return None


def assign_seat(membership, seat):
    """Try to assign a specific seat; returns (ok, reason)."""
    from apps.library.models import Seat

    if not membership.start_date or not membership.end_date:
        membership.compute_dates()
    if not seat.is_active:
        return False, "This seat is inactive."
    if seat.section not in membership.member.allowed_sections:
        return False, "This seat is not in your section."
    if not seat_is_available(
        seat, membership.shift, membership.start_date, membership.end_date,
        exclude_membership=membership, user=membership.member,
    ):
        return False, "This seat is already taken for your shift and dates."
    membership.seat = seat
    membership.save(update_fields=["seat"])
    return True, ""


def activate_membership(membership):
    """Mark a membership active, compute dates and lock its seat.

    Any other active membership of the same member is superseded (cancelled)
    so a member never holds two live memberships at once.
    """
    if membership.status == "active":
        return membership

    membership.compute_dates()
    membership.status = "active"
    membership.save(update_fields=["start_date", "end_date", "status"])

    _supersede_prior_memberships(membership)

    if membership.seat_id:
        ok, _ = assign_seat(membership, membership.seat)
        if not ok:
            logger.info("member %s seat %s no longer available; auto-assigning",
                        membership.member_id, membership.seat_id)
            auto_assign_seat(membership)
    else:
        auto_assign_seat(membership)

    _send_confirmation(membership)
    _confirm_matching_booking(membership)
    return membership


def _confirm_matching_booking(membership):
    """Lock in the member's held booking once the seat is paid & active."""
    from apps.seats.services import confirm_for_membership

    try:
        confirm_for_membership(membership)
    except Exception:
        logger.exception("could not confirm booking for membership %s", membership.id)


def _release_membership_booking(membership):
    """Release any live seat hold tied to this membership's slot.

    Both ``held`` (live hold from checkout) and ``confirmed`` (locked in once
    the membership became active) bookings are cancelled. A confirmed booking
    would otherwise keep blocking the seat forever after the membership
    expires, gets superseded or is cancelled.
    """
    from apps.seats.models import Booking

    Booking.objects.filter(
        user=membership.member,
        seat=membership.seat,
        shift=membership.shift,
        start_date=membership.start_date,
        end_date=membership.end_date,
        status__in=("held", "confirmed"),
    ).update(status="cancelled", held_until=None)


def request_cash_payment(membership):
    """Switch a pending membership to a cash request.

    The seat stays held for 3 days (``CASH_REQUEST_TTL``) while the library
    confirms the cash payment. Only an admin approving the membership (or the
    member paying cash at the desk) converts it into an active pass.
    """
    from apps.seats.models import Booking
    from apps.seats.services import SeatHoldError, hold_seat

    membership.payment_method = "cash"
    membership.status = "pending_cash"
    membership.cash_request_expires_at = timezone.now() + CASH_REQUEST_TTL
    membership.save(
        update_fields=["payment_method", "status", "cash_request_expires_at"]
    )

    if membership.seat_id and membership.start_date and membership.end_date:
        booking = Booking.objects.filter(
            user=membership.member,
            seat=membership.seat,
            shift=membership.shift,
            start_date=membership.start_date,
            end_date=membership.end_date,
            status="held",
        ).first()
        if booking is None:
            try:
                booking = hold_seat(
                    membership.member,
                    membership.seat,
                    membership.shift,
                    membership.start_date,
                    membership.end_date,
                )
            except SeatHoldError:
                logger.warning(
                    "cash request %s could not re-hold seat %s",
                    membership.id,
                    membership.seat_id,
                )
                booking = None
        if booking is not None:
            booking.held_until = timezone.now() + CASH_REQUEST_TTL
            booking.save(update_fields=["held_until"])

    _send_cash_request_ack(membership)
    return membership


def expire_cash_requests():
    """Cancel cash requests not approved by the library within 3 days.

    Releases the held seat and marks the membership cancelled so the slot
    frees up for other members.
    """
    from .models import Membership

    now = timezone.now()
    stale = Membership.objects.filter(
        status="pending_cash",
        cash_request_expires_at__isnull=False,
        cash_request_expires_at__lte=now,
    )
    count = 0
    for membership in stale:
        _release_membership_booking(membership)
        membership.status = "cancelled"
        membership.cash_request_expires_at = None
        membership.save(update_fields=["status", "cash_request_expires_at"])
        count += 1
    if count:
        logger.info("expired %s cash request(s)", count)
    return count


def _send_cash_request_ack(membership):
    from apps.notifications.emails import build_cash_request_acknowledgement
    from apps.notifications.service import notify_membership

    try:
        subject, body, html = build_cash_request_acknowledgement(membership)
    except Exception:
        logger.exception("could not build cash-request ack for membership %s", membership.id)
        return
    notify_membership(
        membership,
        type_="cash_request",
        subject=subject,
        body=body,
        html=html,
    )


def _supersede_prior_memberships(membership):
    from .models import Membership

    prior = Membership.objects.filter(
        member=membership.member, status="active",
    ).exclude(pk=membership.pk).select_related("seat", "shift")
    for old in prior:
        _release_membership_booking(old)
    prior.update(status="cancelled")


def _send_confirmation(membership):
    from apps.notifications.emails import build_membership_confirmation
    from apps.notifications.service import notify_membership

    try:
        subject, body, html = build_membership_confirmation(membership)
    except Exception:
        logger.exception("could not build confirmation email for membership %s", membership.id)
        return
    notify_membership(
        membership,
        type_="confirmation",
        subject=subject,
        body=body,
        html=html,
    )


# ----------------------------------------------------------------- Payments

def create_payment_order(membership):
    """Create a Razorpay order (or a dev mock when unconfigured)."""
    from .models import Payment

    payment, _ = Payment.objects.get_or_create(
        membership=membership,
        defaults={"amount": membership.amount, "method": "upi"},
    )
    if payment.status == "paid":
        return {"already_paid": True}

    order_id = payment.razorpay_order_id
    if not order_id:
        order_id = _razorpay_create_order(membership)
        payment.razorpay_order_id = order_id
        payment.status = "created"
        payment.save(update_fields=["razorpay_order_id", "status"])

    requires_remote = bool(settings.RAZORPAY_KEY_ID and settings.RAZORPAY_KEY_SECRET)
    return {
        "membership_id": str(membership.id),
        "order_id": order_id,
        "key_id": settings.RAZORPAY_KEY_ID,
        "amount": amount_paise(membership.amount),
        "currency": "INR",
        "requires_remote": requires_remote,
        "mock": not requires_remote,
    }


def _razorpay_create_order(membership):
    if not (settings.RAZORPAY_KEY_ID and settings.RAZORPAY_KEY_SECRET):
        return "mock_order_" + str(membership.id).replace("-", "")
    import razorpay

    client = razorpay.Client(
        auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET)
    )
    order = client.order.create(
        {
            "amount": amount_paise(membership.amount),
            "currency": "INR",
            "receipt": f"LS-{str(membership.id)[:8]}",
            "payment_capture": 1,
            "notes": {"membership_id": str(membership.id)},
        }
    )
    return order["id"]


def verify_payment_signature(order_id, payment_id, signature):
    secret = settings.RAZORPAY_KEY_SECRET
    if not secret:
        return False
    message = f"{order_id}|{payment_id}".encode()
    expected = hmac.new(secret.encode(), message, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)


def verify_and_activate(membership, payment_id, signature):
    """Verify the Razorpay signature, then activate the membership.

    Idempotent: calling twice for the same paid membership is a no-op.
    """
    from .models import Payment

    payment = getattr(membership, "payment", None)
    if payment and payment.status == "paid":
        return membership

    payment = payment or Payment.objects.create(
        membership=membership, amount=membership.amount, method="upi"
    )

    order_id = payment.razorpay_order_id or "mock_order_" + str(membership.id).replace("-", "")
    razorpay_configured = bool(settings.RAZORPAY_KEY_ID and settings.RAZORPAY_KEY_SECRET)
    mock_payment = settings.ALLOW_MOCK_PAYMENTS and not razorpay_configured

    valid = verify_payment_signature(order_id, payment_id, signature)
    if not valid and not mock_payment:
        payment.status = "failed"
        payment.save(update_fields=["status"])
        return None

    payment.razorpay_order_id = order_id
    payment.razorpay_payment_id = payment_id
    payment.razorpay_signature = signature
    payment.status = "paid"
    payment.paid_at = timezone.now()
    payment.save()

    return activate_membership(membership)


def expire_overdue_memberships():
    """Mark active memberships past their end_date as expired."""
    from .models import Membership

    today = timezone.localdate()
    expired = Membership.objects.filter(
        status="active", end_date__lt=today
    ).select_related("seat", "shift")
    count = 0
    for membership in expired:
        _release_membership_booking(membership)
        membership.status = "expired"
        membership.save(update_fields=["status"])
        count += 1
    return count


# --------------------------------------------------------- Reminder cycle

def run_reminder_cycle():
    """Daily scheduled job (Celery beat or cron).

    - expires memberships past their end date
    - sends the 7-day-before expiry warning (once)
    - sends a daily reminder each day after that until renewal/expiry
    """
    from datetime import timedelta

    from apps.notifications.models import NotificationLog

    from .models import Membership

    expired = expire_overdue_memberships()
    cash_expired = expire_cash_requests()
    today = timezone.localdate()
    warnings_sent = reminders_sent = 0

    active = (
        Membership.objects.filter(status="active")
        .select_related("member", "shift")
    )
    for membership in active:
        # Day passes expire the same day and do not need renewal reminders.
        if membership.end_date == membership.start_date:
            continue
        days_left = (membership.end_date - today).days
        if days_left == 7:
            if not NotificationLog.objects.filter(
                membership=membership, type="expiry_warning",
                sent_at__date__gte=today - timedelta(days=6),
            ).exists():
                _send_reminder(membership, "expiry_warning")
                warnings_sent += 1
        elif 0 <= days_left < 7:
            if not NotificationLog.objects.filter(
                membership=membership, type="daily_reminder",
                sent_at__date=today,
            ).exists():
                _send_reminder(membership, "daily_reminder")
                reminders_sent += 1

    return {
        "expired": expired,
        "cash_expired": cash_expired,
        "warnings_sent": warnings_sent,
        "reminders_sent": reminders_sent,
    }


def _send_reminder(membership, type_):
    from apps.notifications.emails import build_membership_reminder
    from apps.notifications.service import notify_membership

    subject, body, html = build_membership_reminder(membership, type_)
    notify_membership(membership, type_=type_, subject=subject, body=body, html=html)


def serialize_amount(amount) -> float:
    return float(Decimal(str(amount)))
